const tiSelect = ['/j', '/hj', '/s', '/g', '/gen', '/srs', '/nsrs', '/pos', '/pc', '/neu', '/neg', '/nc', '/p', '/r', '/c', '/l', '/ly', '/lh', '/nm', '/lu', '/nbh', '/nsb', '/nsx', '/nx', '/rh', '/ij', '/m', '/li', '/hyp', '/th', '/cb', '/t', '/f'];

module.exports = tiSelect;